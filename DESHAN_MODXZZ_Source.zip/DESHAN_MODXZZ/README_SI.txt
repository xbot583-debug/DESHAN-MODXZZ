DESHAN MODXZZ — Android Music Search & Downloader
=================================================

මෙය ඔබ upload කළ pair.js එකේ තිබුණු YouTube search / MP3 download API flow එක මත
නිර්මාණය කළ Android source project එකකි.

දැනට ඇතුළත්:
- Dark purple / blue premium-style UI
- Song / artist search
- Search results list (උපරිම 10)
- 128 kbps සහ 320 kbps තේරීම
- Android DownloadManager හරහා Music/DESHAN MODXZZ වෙත save කිරීම
- API token app එකට hardcode නොකර session memory එකේ පමණක් තබාගැනීම
- HTTPS සහ API host validation
- Download කිරීමට පෙර අයිතිය/අවසරය තහවුරු කිරීම
- No account, no analytics, no third-party SDK

API routes (pair.js අනුව):
GET https://whiteshadow-x-api.onrender.com/api/search/yt?q=...&apitoken=...
GET https://whiteshadow-x-api.onrender.com/api/download/ytmp3?url=...&quality=128|320&apitoken=...

ආරක්ෂාව:
- Uploaded pair.js තුළ තිබුණු API token එක source code එකේ hardcoded වී තිබේ.
  එය exposed ලෙස සලකා API provider හරහා rotate/revoke කරන්න.
- අලුත් token එක APK එකට embed කර නැත. App එකේ API ACCESS කොටසට
  ඔබේ අලුත් token එක paste කර USE TOKEN ඔබන්න.
- Token එක app එක open තිබෙන කාලයට පමණක් memory එකේ පවතී.
- App එකෙන් ඔබට අයිතිය ඇති, public-domain, හෝ download කිරීමට අවසර ඇති
  audio පමණක් ලබාගන්න. Provider/API availability වෙනස් විය හැක.

Samsung Galaxy M01 Core:
- minSdk 23 (Android 6.0+)
- Lightweight Java app, external library නැත.
- Internet permission පමණයි.

Phone එකෙන් APK build කිරීම:
1. ZIP එක extract කරන්න.
2. AndroidIDE වැනි Android Gradle project support කරන app එක install/open කරන්න.
3. DESHAN_MODXZZ project folder එක open කරන්න.
4. Gradle sync කරන්න. පළමු sync එකට internet සහ storage ඉඩ අවශ්‍යයි.
5. Build > Assemble Debug තෝරන්න.
6. APK path:
   app/build/outputs/apk/debug/app-debug.apk

සීමාව:
මෙම workspace එකේ Android SDK/Gradle build toolchain නොමැති නිසා APK binary එක
මෙහිදී compile කර නැත. ZIP එකේ Android source project එක සහ build files ඇත.
