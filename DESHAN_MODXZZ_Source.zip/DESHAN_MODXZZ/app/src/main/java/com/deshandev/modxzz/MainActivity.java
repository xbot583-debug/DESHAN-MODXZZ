package com.deshandev.modxzz;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API_BASE = "https://whiteshadow-x-api.onrender.com/api";
    private static final String API_HOST = "whiteshadow-x-api.onrender.com";

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private LinearLayout page;
    private LinearLayout resultsBox;
    private EditText searchInput;
    private EditText tokenInput;
    private TextView statusText;
    private TextView quality128;
    private TextView quality320;
    private ProgressBar progress;
    private CheckBox rightsCheck;
    private String apiToken = "";
    private int selectedQuality = 320;
    private boolean busy = false;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 14, 28));
        getWindow().setNavigationBarColor(Color.rgb(10, 14, 28));
        buildScreen();
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int a, int b, int radiusDp) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{a, b});
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(10, 14, 28));

        page = vertical();
        page.setPadding(dp(18), dp(18), dp(18), dp(32));
        scroll.addView(page);
        setContentView(scroll);

        LinearLayout top = vertical();
        top.setPadding(dp(18), dp(18), dp(18), dp(20));
        top.setBackground(gradient(Color.rgb(31, 48, 91), Color.rgb(83, 46, 143), 26));
        page.addView(top, lp(-1, -2));

        LinearLayout brand = horizontal();
        TextView mark = label("♫", 29, Color.WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(shape(0x33FFFFFF, 16, 0x55FFFFFF, 1));
        brand.addView(mark, lp(52, 52));

        LinearLayout brandText = vertical();
        brandText.setPadding(dp(12), 0, 0, 0);
        brandText.addView(label("DESHAN", 13, 0xFFDCE7FF, true));
        brandText.addView(label("MODXZZ", 25, Color.WHITE, true));
        brand.addView(brandText, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(brand);

        TextView tagline = label("YOUR MUSIC. YOUR FLOW.", 12, 0xFFE0D9FF, true);
        tagline.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams tagLp = lp(-1, -2);
        tagLp.topMargin = dp(20);
        top.addView(tagline, tagLp);

        TextView intro = label("Find a track, choose your quality, and save authorised audio for offline listening.", 14, 0xFFF0EDFF, false);
        intro.setPadding(0, dp(7), 0, 0);
        top.addView(intro);

        addGap(18);
        addSectionTitle("SEARCH MUSIC", "Search by song title, artist, or a supported YouTube URL.");

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(Color.WHITE);
        searchInput.setHintTextColor(0xFF8F9AB5);
        searchInput.setHint("Try: your song or artist name");
        searchInput.setTextSize(15);
        searchInput.setPadding(dp(15), 0, dp(15), 0);
        searchInput.setBackground(shape(0xFF171F35, 15, 0xFF303D5C, 1));
        page.addView(searchInput, lp(-1, 54));

        Button searchButton = actionButton("SEARCH TRACKS  →", true);
        LinearLayout.LayoutParams sbp = lp(-1, 52);
        sbp.topMargin = dp(10);
        page.addView(searchButton, sbp);
        searchButton.setOnClickListener(v -> searchTracks());

        addGap(18);
        addSectionTitle("DOWNLOAD QUALITY", "Choose an MP3 quality for the selected track.");
        LinearLayout qualityRow = horizontal();
        quality128 = qualityChip("128 kbps");
        quality320 = qualityChip("320 kbps");
        qualityRow.addView(quality128, new LinearLayout.LayoutParams(0, dp(46), 1));
        qualityRow.addView(quality320, new LinearLayout.LayoutParams(0, dp(46), 1));
        page.addView(qualityRow);
        updateQualityChips();
        quality128.setOnClickListener(v -> { selectedQuality = 128; updateQualityChips(); });
        quality320.setOnClickListener(v -> { selectedQuality = 320; updateQualityChips(); });

        addGap(18);
        LinearLayout consentCard = vertical();
        consentCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        consentCard.setBackground(shape(0xFF171F35, 16, 0xFF303D5C, 1));
        rightsCheck = new CheckBox(this);
        rightsCheck.setText("I own this audio or have permission to download it.");
        rightsCheck.setTextColor(0xFFE7ECF8);
        rightsCheck.setTextSize(13);
        rightsCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF9D83FF));
        consentCard.addView(rightsCheck);
        TextView rightsNote = label("Use this tool only for your own work, public-domain tracks, or content you are authorised to save. Availability depends on the API provider.", 11, 0xFF9AA7C1, false);
        rightsNote.setPadding(dp(34), dp(2), 0, 0);
        consentCard.addView(rightsNote);
        page.addView(consentCard);

        addGap(18);
        LinearLayout statusRow = horizontal();
        statusText = label("READY WHEN YOU ARE", 12, 0xFF9BA9C5, true);
        statusRow.addView(statusText, new LinearLayout.LayoutParams(0, -2, 1));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        progress.setVisibility(View.GONE);
        statusRow.addView(progress, lp(22, 22));
        page.addView(statusRow);

        addGap(10);
        resultsBox = vertical();
        page.addView(resultsBox);

        addGap(18);
        addSectionTitle("API ACCESS", "Your API token is not built into this APK and is kept in memory only.");
        LinearLayout tokenCard = vertical();
        tokenCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        tokenCard.setBackground(shape(0xFF171F35, 16, 0xFF303D5C, 1));

        tokenInput = new EditText(this);
        tokenInput.setSingleLine(true);
        tokenInput.setTextColor(Color.WHITE);
        tokenInput.setHintTextColor(0xFF8F9AB5);
        tokenInput.setHint("Paste your current API token");
        tokenInput.setTextSize(14);
        tokenInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenInput.setBackground(shape(0xFF0E1528, 12, 0xFF303D5C, 1));
        tokenInput.setPadding(dp(12), 0, dp(12), 0);
        tokenCard.addView(tokenInput, lp(-1, 50));

        Button tokenButton = actionButton("USE TOKEN", false);
        LinearLayout.LayoutParams tbp = lp(-1, 46);
        tbp.topMargin = dp(10);
        tokenCard.addView(tokenButton, tbp);
        tokenButton.setOnClickListener(v -> {
            apiToken = tokenInput.getText().toString().trim();
            if (apiToken.isEmpty()) {
                toast("Enter your API token first.");
                return;
            }
            hideKeyboard();
            tokenInput.setText("");
            status("API token loaded in memory.");
            toast("Token loaded for this session.");
        });

        TextView tokenWarning = label("Security: the token visible in your uploaded pair.js should be treated as exposed. Rotate it with the API provider before using this app. Never share the new token or publish it inside source code.", 11, 0xFFFFC58A, false);
        tokenWarning.setPadding(0, dp(10), 0, 0);
        tokenCard.addView(tokenWarning);
        page.addView(tokenCard);

        addGap(18);
        TextView footer = label("DESHAN MODXZZ  •  OFFLINE-FRIENDLY  •  MADE FOR ANDROID", 10, 0xFF65718D, true);
        footer.setGravity(Gravity.CENTER);
        page.addView(footer);
    }

    private void addGap(int height) {
        View v = new View(this);
        page.addView(v, lp(-1, height));
    }

    private void addSectionTitle(String title, String subtitle) {
        TextView h = label(title, 15, Color.WHITE, true);
        page.addView(h);
        TextView s = label(subtitle, 12, 0xFF8997B3, false);
        s.setPadding(0, dp(4), 0, dp(10));
        page.addView(s);
    }

    private TextView qualityChip(String text) {
        TextView t = label(text, 13, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(0xFF171F35, 14, 0xFF303D5C, 1));
        return t;
    }

    private void updateQualityChips() {
        quality128.setBackground(shape(selectedQuality == 128 ? 0xFF6447C8 : 0xFF171F35,
                14, selectedQuality == 128 ? 0xFFB8A5FF : 0xFF303D5C, 1));
        quality320.setBackground(shape(selectedQuality == 320 ? 0xFF6447C8 : 0xFF171F35,
                14, selectedQuality == 320 ? 0xFFB8A5FF : 0xFF303D5C, 1));
    }

    private Button actionButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(primary
                ? gradient(Color.rgb(120, 83, 235), Color.rgb(67, 105, 224), 15)
                : shape(0xFF293653, 13, 0xFF45567B, 1));
        return b;
    }

    private void searchTracks() {
        if (busy) return;
        if (apiToken.isEmpty()) {
            status("Add your API token below to search.");
            toast("API token required.");
            return;
        }
        String query = searchInput.getText().toString().trim();
        if (query.isEmpty()) {
            searchInput.setError("Enter a song or artist");
            return;
        }
        hideKeyboard();
        setBusy(true, "SEARCHING MUSIC...");
        resultsBox.removeAllViews();

        worker.execute(() -> {
            try {
                String endpoint = API_BASE + "/search/yt?q=" + enc(query)
                        + "&apitoken=" + enc(apiToken);
                JSONObject response = getJson(endpoint, 30000);
                if (!response.optBoolean("success", false)) {
                    throw new Exception(response.optString("message", "Search request failed."));
                }

                JSONArray items = response.optJSONArray("result");
                List<Track> tracks = new ArrayList<>();
                if (items != null) {
                    for (int i = 0; i < items.length() && i < 10; i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item != null) {
                            String title = item.optString("title", "Unknown title");
                            String url = item.optString("url", "");
                            if (!url.isEmpty()) {
                                tracks.add(new Track(title, url,
                                        item.optString("duration", ""),
                                        item.optString("channel", ""),
                                        item.optString("views", "")));
                            }
                        }
                    }
                } else {
                    JSONObject item = response.optJSONObject("result");
                    if (item != null && !item.optString("url", "").isEmpty()) {
                        tracks.add(new Track(item.optString("title", "Unknown title"),
                                item.optString("url"), item.optString("duration", ""),
                                item.optString("channel", ""), item.optString("views", "")));
                    }
                }

                runOnUiThread(() -> {
                    setBusy(false, tracks.isEmpty() ? "NO RESULTS FOUND" : tracks.size() + " TRACKS FOUND");
                    if (tracks.isEmpty()) {
                        resultsBox.addView(label("No tracks found. Try another title or artist.", 13, 0xFFB8C2D8, false));
                    } else {
                        for (Track track : tracks) addTrackCard(track);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, "SEARCH FAILED");
                    showError(e.getMessage());
                });
            }
        });
    }

    private void addTrackCard(Track track) {
        LinearLayout card = vertical();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(shape(0xFF171F35, 17, 0xFF303D5C, 1));
        LinearLayout.LayoutParams cardLp = lp(-1, -2);
        cardLp.bottomMargin = dp(10);
        resultsBox.addView(card, cardLp);

        TextView title = label(track.title, 15, Color.WHITE, true);
        card.addView(title);
        String meta = (track.channel.isEmpty() ? "YouTube result" : track.channel)
                + (track.duration.isEmpty() ? "" : "  •  " + track.duration)
                + (track.views.isEmpty() ? "" : "  •  " + track.views + " views");
        TextView details = label(meta, 11, 0xFF91A0BD, false);
        details.setPadding(0, dp(5), 0, dp(12));
        card.addView(details);

        Button download = actionButton("DOWNLOAD MP3  ↓", true);
        card.addView(download, lp(-1, 46));
        download.setOnClickListener(v -> downloadTrack(track));
    }

    private void downloadTrack(Track track) {
        if (busy) return;
        if (!rightsCheck.isChecked()) {
            toast("Confirm you have permission to download this audio.");
            return;
        }
        if (apiToken.isEmpty()) {
            toast("API token is not loaded.");
            return;
        }

        setBusy(true, "PREPARING MP3...");
        worker.execute(() -> {
            try {
                String endpoint = API_BASE + "/download/ytmp3?url=" + enc(track.url)
                        + "&quality=" + selectedQuality + "&apitoken=" + enc(apiToken);
                JSONObject response = getJson(endpoint, 60000);
                JSONObject result = response.optJSONObject("result");
                String downloadUrl = result == null ? "" : result.optString("download_url", "");
                if (!response.optBoolean("success", false) || downloadUrl.isEmpty()) {
                    throw new Exception(response.optString("message", "The API did not return a download URL."));
                }
                URL parsed = new URL(downloadUrl);
                if (!"https".equalsIgnoreCase(parsed.getProtocol())) {
                    throw new Exception("The provider returned a non-HTTPS download link.");
                }

                runOnUiThread(() -> {
                    try {
                        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                        String filename = safeFilename(track.title) + ".mp3";
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
                        request.setTitle(filename);
                        request.setDescription("DESHAN MODXZZ • " + selectedQuality + " kbps");
                        request.setMimeType("audio/mpeg");
                        request.setNotificationVisibility(
                                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalPublicDir(
                                Environment.DIRECTORY_MUSIC, "DESHAN MODXZZ/" + filename);
                        dm.enqueue(request);
                        setBusy(false, "DOWNLOAD ADDED TO QUEUE");
                        toast("Download started. Check your notifications.");
                    } catch (Exception ex) {
                        setBusy(false, "DOWNLOAD FAILED");
                        showError(ex.getMessage());
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, "DOWNLOAD FAILED");
                    showError(e.getMessage());
                });
            }
        });
    }

    private JSONObject getJson(String endpoint, int timeout) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(endpoint);
            if (!API_HOST.equalsIgnoreCase(url.getHost()) || !"https".equalsIgnoreCase(url.getProtocol())) {
                throw new SecurityException("Unexpected API host.");
            }
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(timeout);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "DESHAN-MODXZZ-Android/1.0");
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new Exception("API returned HTTP " + code);
            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }
            if (code < 200 || code >= 300) {
                throw new Exception("API HTTP " + code + ": " + body.toString().substring(0,
                        Math.min(body.length(), 240)));
            }
            return new JSONObject(body.toString());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String enc(String value) throws Exception {
        return URLEncoder.encode(value, "UTF-8");
    }

    private String safeFilename(String name) {
        String cleaned = name == null ? "track" : name
                .replaceAll("[\\\\/:*?\\\"<>|]", "_")
                .replaceAll("\\s+", " ").trim();
        if (cleaned.isEmpty()) cleaned = "track";
        return cleaned.length() > 90 ? cleaned.substring(0, 90) : cleaned;
    }

    private void setBusy(boolean value, String message) {
        busy = value;
        progress.setVisibility(value ? View.VISIBLE : View.GONE);
        status(message);
    }

    private void status(String message) {
        statusText.setText(message);
    }

    private void showError(String message) {
        String safe = message == null || message.trim().isEmpty()
                ? "Something went wrong. Please try again." : message;
        toast(safe.length() > 150 ? safe.substring(0, 150) : safe);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
        apiToken = "";
    }

    private static class Track {
        final String title, url, duration, channel, views;
        Track(String title, String url, String duration, String channel, String views) {
            this.title = title;
            this.url = url;
            this.duration = duration;
            this.channel = channel;
            this.views = views;
        }
    }
}
