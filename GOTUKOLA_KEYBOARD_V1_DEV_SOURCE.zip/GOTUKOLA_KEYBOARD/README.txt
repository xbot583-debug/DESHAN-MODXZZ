DESHAN MODXZZ — GOTUKOLA KEYBOARD V1
Open DESHAN_MODXZZ as an Android Gradle project. Read DESHAN_MODXZZ/README_SI.txt for Sinhala setup notes, features and known limitations. This is source code, not a prebuilt APK; compile and test on a real Android device before release.
