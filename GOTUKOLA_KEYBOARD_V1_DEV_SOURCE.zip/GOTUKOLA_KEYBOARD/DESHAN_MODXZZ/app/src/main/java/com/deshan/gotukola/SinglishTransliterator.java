package com.deshan.gotukola;

import java.util.HashMap;
import java.util.Map;

/** Small offline starter dictionary. It is deliberately conservative: unknown words remain unchanged. */
public final class SinglishTransliterator {
    private static final Map<String,String> WORDS = new HashMap<>();
    static {
        String[][] pairs = {
            {"mama","මම"},{"oya","ඔයා"},{"oyata","ඔයාට"},{"api","අපි"},{"ape","අපේ"},
            {"mata","මට"},{"mage","මගේ"},{"gedara","ගෙදර"},{"yanna","යන්න"},{"enawa","එනවා"},
            {"yanawa","යනවා"},{"karanna","කරන්න"},{"karanawa","කරනවා"},{"hari","හරි"},
            {"na","නැහැ"},{"naha","නැහැ"},{"ow","ඔව්"},{"ehema","එහෙම"},{"mokakda","මොකක්ද"},
            {"kohomada","කොහොමද"},{"lassanai","ලස්සනයි"},{"hodai","හොඳයි"},{"thanks","ස්තුතියි"},
            {"istuthi","ස්තුතියි"},{"suba","සුබ"},{"udேsanak","උදෑසනක්"},{"ayubowan","ආයුබෝවන්"},
            {"kaema","කෑම"},{"bath","බත්"},{"watura","වතුර"},{"podi","පොඩි"},{"loku","ලොකු"},
            {"amma","අම්මා"},{"thaththa","තාත්තා"},{"yaluwa","යාලුවා"},{"dan","දැන්"},
            {"ada","අද"},{"heta","හෙට"},{"iye","ඊයේ"},{"eka","එක"},{"deka","දෙක"}
        };
        for (String[] p : pairs) WORDS.put(p[0], p[1]);
    }
    private SinglishTransliterator() {}
    public static String convertWord(String word) {
        String result = WORDS.get(word.toLowerCase());
        return result == null ? word : result;
    }
    public static boolean hasWord(String word) { return WORDS.containsKey(word.toLowerCase()); }
}
