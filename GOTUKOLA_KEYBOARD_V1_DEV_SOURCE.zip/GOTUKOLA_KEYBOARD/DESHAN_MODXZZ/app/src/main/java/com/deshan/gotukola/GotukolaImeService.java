package com.deshan.gotukola;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Offline-first Android IME. Typed content is committed directly to the focused app. */
public class GotukolaImeService extends InputMethodService {
    private LinearLayout panel;
    private boolean sinhala = false, symbols = false, singlish = true, shift = false;
    private int bg = 0xff17192a, fg = Color.WHITE;
    private final int keyBg = 0xff30334a;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    @Override public View onCreateInputView() { build(); return panel; }

    private void build() {
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(4), dp(5), dp(4), dp(5)); panel.setBackgroundColor(bg);
        LinearLayout top = new LinearLayout(this);
        addKey(top, sinhala ? "සිංහල" : "EN", () -> { sinhala = !sinhala; symbols = false; build(); }, 2);
        addKey(top, singlish ? "සිංග්ලිෂ් ON" : "සිංග්ලිෂ් OFF", () -> { singlish = !singlish; build(); }, 2);
        addKey(top, "🌿", () -> { symbols = !symbols; build(); }, 1);
        addKey(top, "⌫", this::deleteOne, 1); panel.addView(top);
        if (symbols) {
            row(new String[]{"😀","😂","🥰","❤️","✨","🌿","🙏","👍","🔥","⭐"});
            row(new String[]{"🎉","☀️","🌙","💚","💙","💜","(ツ)","♡","©","®"});
        } else if (sinhala) {
            row(new String[]{"අ","ආ","ඇ","ඈ","ඉ","ඊ","උ","ඌ","එ","ඒ"});
            row(new String[]{"ක","ඛ","ග","ඝ","ච","ජ","ට","ඩ","ත","ද"});
            row(new String[]{"න","ප","බ","ම","ය","ර","ල","ව","ස","හ"});
            row(new String[]{"ා","ැ","ෑ","ි","ී","ු","ූ","ෙ","ේ","ො"});
            row(new String[]{"ෝ","ෞ","්","ං","ඃ","ළ","ෆ","ඟ","ඳ","ඬ"});
        } else {
            row(new String[]{"1","2","3","4","5","6","7","8","9","0"});
            row(new String[]{"q","w","e","r","t","y","u","i","o","p"});
            row(new String[]{"a","s","d","f","g","h","j","k","l"});
            row(new String[]{"⇧","z","x","c","v","b","n","m","⌫"});
        }
        LinearLayout bottom = new LinearLayout(this);
        addKey(bottom, "?123", () -> { symbols = !symbols; build(); }, 1);
        addKey(bottom, "සිං", () -> { sinhala = !sinhala; symbols = false; build(); }, 1);
        addKey(bottom, ",", () -> commit(","), 1);
        addKey(bottom, "Space", this::commitSpace, 4);
        addKey(bottom, ".", () -> commit("."), 1);
        addKey(bottom, "↵", this::enter, 1); panel.addView(bottom);
    }

    private void row(String[] keys) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        for (String key : keys) addKey(r, key, () -> {
            if ("⌫".equals(key)) deleteOne();
            else if ("⇧".equals(key)) { shift = !shift; build(); }
            else commit(!sinhala && shift ? key.toUpperCase() : key);
        }, 1);
        panel.addView(r);
    }

    private void addKey(LinearLayout row, String label, Runnable action, int weight) {
        TextView b = new TextView(this); b.setText(label); b.setTextColor(fg);
        b.setTextSize(label.length() > 3 ? 11 : 17); b.setGravity(17);
        b.setTypeface(null, Typeface.BOLD); b.setBackgroundColor(keyBg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), weight);
        p.setMargins(dp(2), dp(2), dp(2), dp(2)); row.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }

    private void commit(String s) { InputConnection c = getCurrentInputConnection(); if (c != null) c.commitText(s, 1); }
    private void deleteOne() {
        InputConnection c = getCurrentInputConnection();
        if (c != null) { CharSequence selected = c.getSelectedText(0); if (selected != null && selected.length() > 0) c.commitText("", 1); else c.deleteSurroundingText(1, 0); }
    }
    private void commitSpace() {
        InputConnection c = getCurrentInputConnection(); if (c == null) return;
        if (!sinhala && singlish) {
            CharSequence before = c.getTextBeforeCursor(48, 0);
            if (before != null && before.length() > 0) {
                String text = before.toString(); int start = text.length();
                while (start > 0 && Character.isLetter(text.charAt(start - 1))) start--;
                if (start < text.length()) {
                    String word = text.substring(start); String converted = SinglishTransliterator.convertWord(word);
                    if (!word.equals(converted)) { c.deleteSurroundingText(word.length(), 0); c.commitText(converted, 1); }
                }
            }
        }
        c.commitText(" ", 1);
    }
    private void enter() { InputConnection c = getCurrentInputConnection(); if (c != null) c.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); }
}
