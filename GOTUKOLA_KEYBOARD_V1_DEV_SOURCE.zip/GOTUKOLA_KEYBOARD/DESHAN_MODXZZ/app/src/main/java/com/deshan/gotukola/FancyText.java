package com.deshan.gotukola;

import java.util.HashMap;
import java.util.Map;

public final class FancyText {
 private FancyText() {}
 private static String map(String s, int upper, int lower, int digits) {
  StringBuilder b=new StringBuilder();
  for(char c:s.toCharArray()) {
   if(c>='A'&&c<='Z') b.appendCodePoint(upper+(c-'A'));
   else if(c>='a'&&c<='z') b.appendCodePoint(lower+(c-'a'));
   else if(c>='0'&&c<='9'&&digits>0) b.appendCodePoint(digits+(c-'0'));
   else b.append(c);
  }
  return b.toString();
 }
 public static String transform(String s,String style) {
  switch(style) {
   case "Bold": return map(s,0x1D400,0x1D41A,0x1D7CE);
   case "Italic": return map(s,0x1D434,0x1D44E,0);
   case "Bold Italic": return map(s,0x1D468,0x1D482,0);
   case "Script": return map(s,0x1D49C,0x1D4B6,0);
   case "Double Struck": return map(s,0x1D538,0x1D552,0x1D7D8);
   case "Monospace": return map(s,0x1D670,0x1D68A,0x1D7F6);
   case "Sans Bold": return map(s,0x1D5D4,0x1D5EE,0x1D7EC);
   case "Gothic": return map(s,0x1D504,0x1D51E,0);
   case "Bubble":
    StringBuilder b=new StringBuilder(); for(char c:s.toCharArray()){if(c>='A'&&c<='Z')b.appendCodePoint(0x24B6+c-'A');else if(c>='a'&&c<='z')b.appendCodePoint(0x24D0+c-'a');else b.append(c);} return b.toString();
   case "Small Caps":
    String from="abcdefghijklmnopqrstuvwxyz",to="ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"; String out=s; for(int i=0;i<from.length();i++)out=out.replace(from.charAt(i),to.charAt(i));return out;
   case "Spaced": return String.join(" ",s.split("",-1)).trim();
   case "Underline": return s.replaceAll("(.)","$1̲");
   case "Strike": return s.replaceAll("(.)","$1̶");
   case "Hearts": return "♡ "+s+" ♡";
   case "Stars": return "✦ "+s+" ✦";
   default:return s;
  }
 }
 public static String[] styles(){return new String[]{"Bold","Italic","Bold Italic","Script","Double Struck","Monospace","Sans Bold","Gothic","Bubble","Small Caps","Spaced","Underline","Strike","Hearts","Stars"};}
}
