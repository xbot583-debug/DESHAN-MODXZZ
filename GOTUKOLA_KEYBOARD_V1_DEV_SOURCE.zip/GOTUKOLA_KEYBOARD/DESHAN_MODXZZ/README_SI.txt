DESHAN MODXZZ - GOTUKOLA KEYBOARD V1 (development build)

ව්‍යාපෘතිය
- Android application ID: com.deshan.gotukola
- Minimum Android: API 23 (Android 6.0); target API 28 for legacy IME compatibility testing.
- Java, Android SDK, Android Gradle Plugin 8.7.3, Gradle 8.9 recommended.

දැනට source එකේ ඇතුළත්
- Android InputMethodService registration.
- English QWERTY keyboard with number row, shift, backspace, space and enter.
- Sinhala character/diacritic grid (starter layout; not yet a complete Wijesekara layout).
- Offline Singlish starter dictionary for selected common words. Unknown words remain as typed.
- Emoji/kaomoji quick panel.
- Main app screens: Fancy Text Studio, Message Magic, Emoji/Kaomoji, Theme preferences, Tools, Saver Center and Privacy/Settings.
- Local-only preferences; typed text is not sent to a server by this source.

තවම release-ready නොවන කොටස්
- Full Sinhala Unicode composition, complete Wijesekara and accurate transliteration engine.
- Predictive suggestions, autocorrect language model, swipe typing and voice input.
- GIF/sticker provider integration.
- Real QR generation bundled in-app; current QR action uses an external preview page.
- Background download manager and WhatsApp status integration.
- Google/Email authentication and cloud sync backend.
- Full device/API compatibility and accessibility testing.

Build
1. Install Android Studio or use a compatible Android build environment.
2. Open this folder as a Gradle project.
3. Use JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compile SDK 35.
4. Build :app:assembleDebug.
5. Install on a test phone. Open app -> Enable / Select Keyboard -> select Gotukola Keyboard.
6. Test in a text field before using as the default keyboard.

Privacy design
- This IME does not request INTERNET permission in the current manifest.
- It does not log keystrokes or upload typed content.
- Cloud services must not be added without a documented privacy policy, explicit opt-in, secure auth, and backend secret management.

This is an active development source snapshot, not a signed production APK and not a claim of universal device compatibility.
